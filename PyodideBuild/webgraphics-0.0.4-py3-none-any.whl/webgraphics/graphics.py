import numpy as np
import colorsys
import math
from js import document
import asyncio
import time

class Canvas:
    __mouse_x = None
    __mouse_y = None

    def __init__(self, width, height):
        self.canvas = document.getElementById('canvas')

        self.canvas.setAttribute('width', width)
        self.canvas.setAttribute('height', height)
        # display the canvas
        self.canvas.setAttribute('display', '')
        self.context = self.canvas.getContext("2d")
        self.canvas.style.width = str(width) + "px"
        self.canvas.style.height = str(height) + "px"
        self.context.clearRect(0, 0, width, height)
        print("CANVAS INIT", self)

        # for keeping track of how long to sleep
        self.last_sleep_time = None

    def draw_circle(self, radius, center_x, center_y, color):
        print("DRAW CIRCLE", self)
        self.context.beginPath()
        self.context.fillStyle=color
        self.context.arc(center_x, center_y, radius, 0, 2 * math.pi)
        self.context.fill()

    def clear(self):
        self.context.clearRect(0, 0, self.canvas.width, self.canvas.height)

    def get_mouse_x(self):
        # this doesn't work. use global get_mouse_x instead
        return Canvas.__mouse_x

    def get_mouse_y(self):
        # this doesn't work. use global get_mouse_x instead
        return Canvas.__mouse_y

    async def pause(self, target_time):
        # TODO: if you are consistently rendering slow, you can reduce
        # the re-render frame rate by skipping the sleep command.
        if self.last_sleep_time == None:
            await asyncio.sleep(target_time)
        else:
            elapsed_time = time.time() - self.last_sleep_time
            remaining_time = target_time - elapsed_time
            await asyncio.sleep(max(0, remaining_time))
        self.last_sleep_time = time.time()

def create_canvas(width, height):
    canvas = Canvas(width, height)
    print("CREATE CANVAS", canvas)
    return canvas

def random_color():
    """
    Generates a random color in HSV space, then
    translates it into RGB space. Feel free to edit
    """
    h = np.random.uniform(200,300) / 360
    s = np.random.uniform(0.5, 0.9)
    v = np.random.uniform(.7, .9)
    (r,g,b) = colorsys.hsv_to_rgb(h, s, v)
    return f'rgb({r*256},{g*256},{b*256})'
