from js import jskarel
import time
import random as rndm


jsKarelClient = jskarel.setup_karel()


# __DIR_DELTA__ = [(1, 0), (0, -1), (-1, 0), (0, 1)]


def run_karel_program():
    rpkcount = jskarel.incRkp()
    if rpkcount < 2:
        userModName = jskarel.getUserModName()
        student_mod = __import__(userModName)
        jskarel.setKarelActive()
        student_mod.main()
    if rpkcount > 3:
        raise Exception("run_karel_program called twice")






def move():
    if not front_is_clear():
        raise Exception("Front is blocked")
    time.sleep(jskarel.getSleepTime())
    jsKarelClient.move()


def turn_left():
    time.sleep(jskarel.getSleepTime())
    jsKarelClient.turn_left()


def put_beeper():
    time.sleep(jskarel.getSleepTime())
    jsKarelClient.put_beeper()


def pick_beeper():
    if beepers_present() < 1:
        raise Exception("No beepers present")
    time.sleep(jskarel.getSleepTime())
    jsKarelClient.pick_beeper()


def front_is_clear():
    return jsKarelClient.front_is_clear()


def front_is_blocked():
    return not front_is_clear()


def left_is_clear():
    return jsKarelClient.left_is_clear()



def left_is_blocked():
    return not left_is_clear()


def right_is_clear():
    return jsKarelClient.right_is_clear()


def right_is_blocked():
    return not right_is_clear()


def beepers_present():
    return jsKarelClient.beepers_present()


def no_beepers_present():
    return not beepers_present()


def beepers_in_bag():

    return jsKarelClient.beepers_in_bag()


def no_beepers_in_bag():

    return not beepers_in_bag()


def facing_north():

    return jsKarelClient.facing_north()

def not_facing_north():

    return not facing_north()


def facing_east():

    return jsKarelClient.facing_east()


def not_facing_east():

    return not facing_east()


def facing_west():

    return jsKarelClient.facing_west()


def not_facing_west():

    return not facing_west()


def facing_south():
    return jsKarelClient.facing_south()


def not_facing_south():

    return not facing_south()


def paint_corner(color):
    time.sleep(jskarel.getSleepTime())
    jsKarelClient.paint_corner(color)


def corner_color_is(color):
    return jsKarelClient.corner_color_is(color)


def random(d=0.5):
    return rndm.uniform(0, 1) < d

